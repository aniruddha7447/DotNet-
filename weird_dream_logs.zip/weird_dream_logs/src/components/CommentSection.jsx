import { useState, useEffect } from 'react';
import API from '../services/api';
import '../styles/CommentSection.css';

export default function CommentSection({ postId, comments, setComments, currentUser, fetchComments }) {
  const [content, setContent] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAdd = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const response = await API.post('/Comments', { content, dreamId: postId });
      setContent('');
      setComments([
        ...comments,
        {
          ...response.data,
          Username: currentUser?.username 
        }
      ]);
      if (fetchComments) await fetchComments();
    } catch (err) {
      setError('Failed to comment.');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Delete this comment?')) {
      try {
        await API.delete(`/Comments/${id}`);
        setComments(comments.filter(c => c.id !== id));
        if (fetchComments) await fetchComments();
      } catch (err) {
        setError('Failed to delete comment.');
      }
    }
  };

  return (
    <div className="comment-section">
      <form onSubmit={handleAdd} className="comment-form">
        <input
          type="text"
          placeholder="Add a comment..."
          value={content}
          onChange={e => setContent(e.target.value)}
          required
          disabled={loading}
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Posting...' : 'Comment'}
        </button>
      </form>
      {error && <div className="error">{error}</div>}
      <div className="comments-list">
        {comments && comments.length > 0 ? (
          comments.map(c => (
            <div key={c.id} className="comment">
              <span><b>{c.Username || c.username}:</b> {c.content}</span>
              <span className="comment-date">{new Date(c.createdAt).toLocaleString()}</span>
              <button onClick={() => handleDelete(c.id)} className="delete">Delete</button>
            </div>
          ))
        ) : (
          <p className="no-comments">No comments yet. Be the first to comment!</p>
        )}
      </div>
    </div>
  );
} 