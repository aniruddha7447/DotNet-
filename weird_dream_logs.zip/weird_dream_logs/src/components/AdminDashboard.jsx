import { useState, useEffect } from 'react';
import API from '../services/api';
import Post from './Post';
import '../styles/AdminDashboard.css';

export default function AdminDashboard({ user }) {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const res = await API.get('/Dreams');
      setPosts(res.data);
    } catch (err) {}
    setLoading(false);
  };

  const filteredPosts = posts.filter(post =>
    post.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.content?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="admin-dashboard-container">
      <div className="admin-dashboard-card">
        <h2>Admin Dashboard</h2>
        {loading ? <p>Loading...</p> : (
          <>
            <div className="search-bar" style={{marginBottom:'1.5em', display:'flex', justifyContent:'flex-end'}}>
              <label htmlFor="admin-search-input" style={{marginRight:'0.5em'}}>Search:</label>
              <input
                id="admin-search-input"
                type="text"
                placeholder="Search dreams..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                style={{padding:'0.4em 1em',borderRadius:'8px',border:'1px solid #ccc',minWidth:'200px'}}
              />
            </div>
            <div className="posts-list-grid">
              {filteredPosts.map(post => (
                <Post key={post.id} post={post} currentUser={user} onUpdate={fetchPosts} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
} 