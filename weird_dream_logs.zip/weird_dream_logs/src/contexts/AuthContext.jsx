import { createContext, useContext, useState, useEffect } from 'react';
import API from '../services/api';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      API.get('/Users/me')
        .then(res => setUser(res.data))
        .catch(() => setUser(null));
    }
    setLoading(false);
  }, []);

  const login = async (user, token) => {
    localStorage.setItem('token', token);
    try {
      const res = await API.get('/Users/me');
      setUser(res.data);
    } catch {
      setUser(user); // fallback
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('token');
  };

  const updateUser = (newUser) => {
    setUser(newUser);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
} 