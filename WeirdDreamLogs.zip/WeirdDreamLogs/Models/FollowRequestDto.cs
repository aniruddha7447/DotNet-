namespace WeirdDreamLogs.Models
{
    public class FollowRequestDto
    {
        public int RequesterId { get; set; }
        public int TargetId { get; set; }
    }
} 