namespace WeirdDreamLogs.Models
{
    public class RequestIdDto
    {
        public int RequestId { get; set; }
    }
} 