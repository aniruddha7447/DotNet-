namespace WeirdDreamLogs.Models
{
    public class UserPairDto
    {
        public int FollowerId { get; set; }
        public int FollowedId { get; set; }
    }
} 