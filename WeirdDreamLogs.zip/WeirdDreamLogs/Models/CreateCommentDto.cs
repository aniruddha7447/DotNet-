namespace WeirdDreamLogs.Models
{
    public class CreateCommentDto
    {
        public string Content { get; set; }
        public int DreamId { get; set; }
    }
} 