namespace WeirdDreamLogs.Models
{
    public class CreateLikeDto
    {
        public int DreamId { get; set; }
    }
} 